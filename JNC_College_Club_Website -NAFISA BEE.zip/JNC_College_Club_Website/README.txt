JNC COLLEGE CLUB MANAGEMENT PORTAL

Files:
- index.html: website structure
- style.css: premium purple responsive styling
- script.js: menus, club selection, event filters, demo login and registration
- images/college.png: college image supplied by you

RUN IN VS CODE:
1. Extract the ZIP file.
2. Open the extracted folder in Visual Studio Code.
3. Open index.html.
4. If Live Server extension is installed, right-click index.html and choose "Open with Live Server".
   Or double-click index.html to open it in your browser.

NOTES:
- Registration is a demo and saves data only in the same browser's local storage.
- Login is a visual demo; real authentication and college-side submissions require a backend.
- Some fonts require an internet connection.
